% ADVISOR data file:  EX_FUELCELL.m
%
% Data source:
%
% Data confirmation:
%
% Notes:  Defines exhaust aftertreatment catalyst parameters for use with ADVISOR 2, for
% a hypothetical vehicle equipped with a fuel cell.
% Masses, areas, etc. are scaled based on fuel cell peak power (fc_pwr_max)
% 
% Created on: 14-JAN-99
% By:  SDB, NREL, steve_burch@nrel.gov
%
% Revision history at end of file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FILE ID INFO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_description='default catalyst for fuel cell';
ex_version=2003;     % version of ADVISOR for which the file was generated
ex_proprietary=0;   % 0=> non-proprietary, 1=> proprietary, do not distribute
ex_validation=0;    % 1=> no validation, 1=> data agrees with source data, 
                    % 2=> data matches source data and data collection methods verified
disp(['Data loaded: EX_FUELCELL - ',ex_description])

ex_calc=1;          % 0=> skip ex sys calc (if fc has no emis maps or no cat info avail)
                    % 1=> perform ex sys calcs including tailpipe emis
ex_ornl_bool=0;			%1->Use efficiencies from ORNL data
						%0->Use basic ADVISOR removal efficiencies

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CAT EFF VS TEMPERATURE 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_cat_tmp_range=[-40 0 220 240 310 415 475 550 650 1200]; % (deg. C)
% catalyst's temperature-dependent conversion efficiencies indexed by ex_cat_temp_range
%ex_cat_hc_frac=[0 0 0 0 0.6 0.84 0.92 1 1 1]*0.85;  % (--)
%ex_cat_co_frac=[0 0 0 0.48 0.82 0.93 0.96 1 1 1]*0.95; % (--)
%ex_cat_nox_frac=[0 0 0.09 0.2 0.89 0.99 0.99 1 1 1]*0.91; % (--)
%ex_cat_pm_frac=[0 0 0 0 0 0 0 0 0 0];  % (--)

% override with zero conversion efficiency values
% thus catalyst will have no effect and engine out 
% values will be displayed in gui
ex_cat_hc_frac=[0 0 0 0 0 0 0 0 0 0];  % (--)
ex_cat_co_frac=[0 0 0 0 0 0 0 0 0 0]; % (--)
ex_cat_nox_frac=[0 0 0 0 0 0 0 0 0 0]; % (--)
ex_cat_pm_frac=[0 0 0 0 0 0 0 0 0 0];  % (--)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CAT "BREAKTHROUGH" LIMITS (MAX g/s for each pollutant) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_cat_lim= [1.25 17.0 2.0 0.4]';     % g/s  "break-thru" limit of converter (HC, CO, NOx)
                                      % assumed to be ~5X the Tier 1 g/mi limits

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NEW CONVERTER, ETC DATA		
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONVENTIONAL CONVERTER
ex_mass=0.26*fc_max_pwr/fc_pwr_scale;  % kg     mass of exhaust system assumes mass penalty of 0.26 kg/kW (from 1994 OTA report, Table 3)
 ex_cat_mass=ex_mass*0.36;           % kg     mass of catalytic converter (from 1994 OTA report, Table 3)
  ex_cat_mon_mass=ex_cat_mass*0.22;   % kg     mass of cat monolith (ceramic)
  ex_cat_int_mass=ex_cat_mass*0.33;   % kg     mass of cat internal SS shell 
  ex_cat_pipe_mass=ex_cat_mass*0.17;  % kg     mass of cat inlet/outlet pipes
  ex_cat_ext_mass=ex_cat_mass*0.28;   % kg     mass of cat ext shell (shield)
 ex_manif_mass=ex_mass*0.18;         % kg     mass of engine manifold & downpipe
 ex_muf_mass=ex_mass-ex_cat_mass-ex_manif_mass;  % kg     mass of muffler and other pipes downstream of cat
 
ex_cat_pcm_mass=0;                  % kg     mass of cat phase change mat'l heat storage 
ex_mass=ex_mass+ex_cat_pcm_mass;    % kg     add mass of PCM (if any) to ex sys mass

ex_cat_mon_cp=1070;        % J/kgK  ave cp of cat int: CERAMIC MON. (SAE #880282)
%ex_cat_mon_cp=636;        % J/kgK  ave cp of cat int: METAL MON. (SAE #890798)
ex_cat_int_cp=460;         % J/kgK  ave cp of cat int: METAL MON. (SAE #890798)
ex_cat_pipe_cp=460;        % J/kgK  ave sens heat cap of cat i/o pipes (SAE #890798)
ex_cat_ext_cp=460;         % J/kgK  ave sens heat cap of cat ext (SAE #890798)
ex_manif_cp=460;           % J/kgK  ave sens heat cap of manifold & dwnpipe (SAE #890798)
ex_gas_cp=1089;            % J/kgK  ave sens heat cap of exh gas (SAE #890798)
ex_cat_pcm_tmp=[-100 1200];  % C   temp range for cat pcm ecp vec
ex_cat_pcm_ecp=[0 0];      % J/kgK  ave eff heat cap of pcm (latent + sens)

ex_cat_mon_sarea=0.1*(fc_max_pwr/100)^0.67; % m^2  outer surface area of cat monolith (approx. 0.1 m^2/100 kW)
ex_cat_monf_sarea=ex_cat_mon_sarea/4;    % m^2  surface area of cat monolith front face
ex_cat_moni_sarea=ex_cat_mon_sarea*50;   % m^2  inner (honeycomb) surf area of cat monolith
ex_cat_int_sarea=ex_cat_mon_sarea*1.3;   % m^2  surface area of cat interior
ex_cat_pipe_sarea=ex_cat_mon_sarea/2;    % m^2  surface area of cat i/o pipes
ex_cat_ext_sarea=ex_cat_mon_sarea*1.4;   % m^2  surface area of cat ext shield
ex_man2cat_length=0.7;                   % m    length of exhaust pipe between manifold and cat conv
ex_manif_sarea=(fc_max_pwr/600)*(0.3+ex_man2cat_length);    % m^2  surface area of manif & downpipe: pi*D*L

ex_cat_m2p_emisv=0.1;       %        emissivity x view factor from cat monolith to cat pipes
ex_cat_i2x_emisv=0.5;       %        emissivity from cat int to cat ext shield
ex_cat_pipe_emisv=0.7;      %        emissivity of cat i/o pipe
ex_cat_ext_emisv=0.7;       %        emissivity of cat ext shield
ex_manif_emisv=0.7;         %        emissivity of manif & dwnpipe

ex_cat_m2i_th_cond=[0.7 1.3 2.65 6.5]*0.1/0.003 ; % W/K   cond btwn CERAMIC mono & int (from SAE#880282)
ex_cat_m2i_tmp=[-40 97 344 1200];                % C     corresponding temperature vector
ex_cat_i2x_th_cond   =1.0;                        % W/K    conductance btwn cat int & ext
ex_cat_i2p_th_cond   =0.2;                        % W/K    conductance btwn cat int & pipe
ex_cat_p2x_th_cond   =0.02;                       % W/K    conductance btwn cat pipe & ext

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STUFF FOR OLD CAT TEMP APPROACH 	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_cat_max_tmp=550;                              % deg. C, maximum catalyst temperature 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT SCALING 	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% user definable mass scaling function
ex_mass_scale_fun=inline('(x(1)*fc_pwr_scale+x(2))*ex_mass','x','fc_pwr_scale','ex_mass');
ex_mass_scale_coef=[1 0]; % mass scaling function coefficients

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REVISION HISTORY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 06/21/99:tm created for use with Plug Power/Epyx fuel cell data and the gui
% 11/01/99:tm renamed fc_fuelcell_null to fc_fuelcell
% 11/3/99:ss updated *_version to 2.21 from 2.2 and divided fc_max_pwr by fc_pwr_scale 
%                  since it is scaled back up in block diagram
% 02/26/01: vhj added variable ex_abs_bool
% 02/28/01: vhj changed ex_abs_bool to ex_ornl_bool
% 7/30/01:tm added mass scaling relationship mass=f(ex_mass,fc_pwr_scale)
