% TEST_ACCEL
%
% This test procedure provides the ability to determine the
% acceleration performance of a vehicle under various input conditions.
%

AccelFigControl

%Revision History
%7/14/00 ss,tm: created